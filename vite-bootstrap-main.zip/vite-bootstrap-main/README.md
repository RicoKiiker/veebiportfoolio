#Paketi juhis

#Alustades tööd
Igakordselt alustades tööd puhtas arvutis, kui projekti pole , siis git clone
`git clone [repoaadress] (https://github.com/RicoKiiker/vite-bootstrap.git)`

## Pärast kloonimist
npm install et alla laeks

## git pull kui projekt on olemas arvutis

## Käivitamine
npm run start serveri jaoks